import asyncio
#import time
import random as rnd 
import websockets
 
a=open('/srv/glags.txt','r').read().split('\n')[:-1]

print(len(a), 'verbs loaded')
#async def handler(websocket, path):
# 
#    data = await websocket.recv()
# 
#    reply = f"Data recieved as:  {data}!"
# 
#    await websocket.send(reply)
 
async def jojo_phrase(ws,path):
    data = await ws.recv()
    jjhp=4
    adhp=1000
    idx=[rnd.randint(1,len(a)) for i in range(5)]
    d=[rnd.randint(1,len(a)//2) for i in range(5)]
    phrase=f'Я хочу { a[idx[0]] } чтобы { a[idx[1]] }, а потом { a[idx[2]] } и, будучи победителем, приказать { a[idx[3]] } тебе, ДжоДжо, так сильно пытающийся { a[idx[4]] }!!!'
    await ws.send('photo 3')
    data = await ws.recv()
    while(jjhp>0 and adhp>0):
        await ws.send(phrase)
        if(data==phrase):
            adhp-=1
            reply = 'Его хомон прошёл сквозь мою кожу и продолжает струиться! Он так хорошо изучил хомон всего за 3 недели?'
            await ws.send(reply)
            await ws.send('photo 7')
        else:
            jjhp-=1
            reply = 'не угадал!'
            await ws.send(reply)
            reply = 'Похоже, ты действительно напуган. Страх уступает место спешке, приводящей к поражению отчаяньем, ДжоДжо!'
            await ws.send(reply)
            await ws.send('photo 4')
        await ws.send(f'JoJo hp: { jjhp }; ad hp: { adhp }')
        data=await ws.recv()
        for i in range(5):
            idx[i]+=d[i]
            idx[i]%=len(a)
        phrase=f'Я хочу { a[idx[0]] } чтобы { a[idx[1]] }, а потом { a[idx[2]] } и, будучи победителем, приказать { a[idx[3]] } тебе, ДжоДжо, так сильно пытающийся { a[idx[4]] }!!!'
    #print(1)
    if(adhp==0):
        #print(2)
        reply='js:Может, ты и перехитрил меня, но я перехитрил твою хитрость!!!'
        await ws.send(reply)
        await ws.send('photo 1')
        await ws.send('photo 2')
        await ws.send('ctf{guess_reverse_jusddf}')
    else:
        reply='Ты проиграл, ДжоДжо!'
        await ws.send(reply)
    await ws.recv()
 
start_server = websockets.serve(jojo_phrase, "0.0.0.0", 8000)
 
 
 
asyncio.get_event_loop().run_until_complete(start_server)
 
asyncio.get_event_loop().run_forever()
