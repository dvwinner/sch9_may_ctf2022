
import asyncio
#import time
import random as rnd 
import websockets
 
#async def handler(websocket, path):
# 
#    data = await websocket.recv()
# 
#    reply = f"Data recieved as:  {data}!"
# 
#    await websocket.send(reply)
 
async def calculator(ws,path):
    data = await ws.recv()
    await ws.send(str(eval(data)))
 
start_server = websockets.serve(calculator, "0.0.0.0", 8000)
 
 
 
asyncio.get_event_loop().run_until_complete(start_server)
 
asyncio.get_event_loop().run_forever()
